"""
Chilean Electricity Market Analytics Platform
Streamlit app with exploration, SQL, forecasting, anomalies, and AI agent.
"""

import os, sys, json
import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

sys.path.insert(0, os.path.dirname(__file__))
from pipeline import (
    clean_data, generate_synthetic_series, detect_anomalies,
    prepare_price_series, decompose_and_forecast, create_db, run_sql
)

# ─── Page config ─────────────────────────────────────────────────────────────
st.set_page_config(page_title="Galilei -- Electricity Market Analytics", page_icon="⚡",
                   layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
.main-header {font-size:1.8rem; font-weight:700; color:#0a1628; margin-bottom:0.2rem;}
.sub-header {font-size:0.95rem; color:#5a6a7a; margin-bottom:1.2rem;}
/* Chat */
.chat-bubble-user {
    background:#1b6ef3; color:white; border-radius:16px 16px 4px 16px;
    padding:0.65rem 1rem; margin:0.3rem 0 0.3rem 20%; font-size:0.92rem; line-height:1.5;
}
.chat-bubble-agent {
    background:#edf2f7; color:#1a202c; border-radius:16px 16px 16px 4px;
    padding:0.65rem 1rem; margin:0.3rem 20% 0.3rem 0; font-size:0.92rem; line-height:1.5;
    border-left:3px solid #1b6ef3;
}
.chat-tool {
    background:#fffbeb; color:#92400e; border-radius:6px;
    padding:0.25rem 0.8rem; margin:0.1rem 20% 0.1rem 0;
    font-size:0.75rem; font-style:italic; border-left:3px solid #f59e0b;
}
.chat-label {font-size:0.7rem; color:#a0a8b4; margin:0.4rem 0 -4px;}
.chat-welcome {text-align:center; padding:2rem; color:#a0a8b4;}
.chat-welcome h3 {color:#1a202c; font-size:1.15rem; margin-bottom:0.4rem;}
</style>
""", unsafe_allow_html=True)

# ─── Data loading (cached) ───────────────────────────────────────────────────
@st.cache_data(show_spinner=False)
def load_all():
    mercado_clean = clean_data()
    sim = generate_synthetic_series()
    anomalies = detect_anomalies(sim)

    forecasts = {}
    for barra in ['Quillota', 'Alto Jahuel']:
        ts = prepare_price_series(sim, barra)
        forecasts[barra] = decompose_and_forecast(ts, forecast_hours=168)

    return mercado_clean, sim, anomalies, forecasts

mercado_clean, sim, anomalies_df, forecasts = load_all()

@st.cache_resource
def get_db():
    return create_db(sim)

conn = get_db()

# ─── Sidebar ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### ⚡ Galilei Analytics")
    page = st.radio("", ["🏠 Overview", "📊 Exploration", "🔮 Forecast",
                         "🔍 Anomalies", "💾 SQL Console", "🤖 AI Agent"],
                    label_visibility="collapsed")
    st.markdown("---")
    st.caption(f"Simulated data: {len(sim):,} rows")
    st.caption(f"Period: 2024-01-01 to 2024-12-31")
    st.caption(f"Barras: Quillota, Alto Jahuel")
    st.caption(f"Plants: Los Condores, Volcan, Cerro Pabellon")


# ════════════════════════════════════════════════════════════════════════════
# OVERVIEW
# ════════════════════════════════════════════════════════════════════════════
if page == "🏠 Overview":
    st.markdown('<p class="main-header">⚡ Chilean Electricity Market Analytics</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Spot prices, generation, revenue analysis -- simulated 1-year hourly dataset</p>', unsafe_allow_html=True)

    c1,c2,c3,c4,c5 = st.columns(5)
    c1.metric("Total Rows", f"{len(sim):,}")
    avg_q = sim[sim['barra']=='Quillota']['precio_spot'].mean()
    avg_a = sim[sim['barra']=='Alto Jahuel']['precio_spot'].mean()
    c2.metric("Avg Price Quillota", f"${avg_q:.1f}")
    c3.metric("Avg Price Alto Jahuel", f"${avg_a:.1f}")
    c4.metric("Spread", f"${avg_a - avg_q:.1f}")
    c5.metric("Anomalies", len(anomalies_df))

    st.markdown("---")
    cl, cr = st.columns(2)
    with cl:
        st.markdown("#### About this platform")
        st.markdown("""
        This is a demonstration analytics platform for the Chilean electricity market (SEN).
        It processes spot prices and generation data across two main barras and three plants.

        **Data pipeline:**
        - Raw data cleaning (null handling, type coercion, key normalization)
        - Synthetic hourly data generation with trend, seasonality, and AR(1) residuals
        - SQLite persistence for ad-hoc SQL analysis
        - Time series decomposition and 7-day forecasting
        - Rule-based anomaly detection
        """)
    with cr:
        st.markdown("#### Data architecture")
        st.markdown("""
        | Component | Detail |
        |---|---|
        | **Barras** | Quillota (coastal), Alto Jahuel (Santiago) |
        | **Plants** | Los Condores (hydro), Volcan (wind), Cerro Pabellon (solar) |
        | **Frequency** | Hourly (8,760 hours x 3 plants = 26,280 rows) |
        | **Price model** | Base + trend + annual + daily seasonality + AR(1) |
        | **Generation** | Type-specific patterns (solar bell, hydro seasonal, wind variable) |
        | **Forecast** | Additive decomposition + 168h horizon with CI |
        | **Anomalies** | Rule-based: negative prices, z-score >3, solar at night |
        """)


# ════════════════════════════════════════════════════════════════════════════
# EXPLORATION
# ════════════════════════════════════════════════════════════════════════════
elif page == "📊 Exploration":
    st.markdown('<p class="main-header">📊 Market Exploration</p>', unsafe_allow_html=True)

    tab1,tab2,tab3,tab4 = st.tabs(["Prices", "Generation", "Revenue", "Exchange Rate"])

    with tab1:
        # Hourly price by barra
        daily_price = sim.groupby(['fecha','barra'])['precio_spot'].mean().reset_index()
        fig = px.line(daily_price, x='fecha', y='precio_spot', color='barra',
                      title="Daily Average Spot Price by Barra (USD/MWh)",
                      labels={'precio_spot':'Price (USD/MWh)','fecha':'Date'},
                      color_discrete_map={'Quillota':'#1b6ef3','Alto Jahuel':'#f97316'})
        fig.update_layout(template='plotly_white', height=400)
        st.plotly_chart(fig, use_container_width=True)

        # Hourly profile
        hourly = sim.groupby(['hora','barra'])['precio_spot'].mean().reset_index()
        fig2 = px.line(hourly, x='hora', y='precio_spot', color='barra',
                       title="Average Price by Hour of Day (Duck Curve Effect)",
                       labels={'precio_spot':'Price (USD/MWh)','hora':'Hour'},
                       color_discrete_map={'Quillota':'#1b6ef3','Alto Jahuel':'#f97316'})
        fig2.update_layout(template='plotly_white', height=350)
        st.plotly_chart(fig2, use_container_width=True)
        st.caption("Notice the solar dip at hours 10-15 and demand peak at 18-22.")

    with tab2:
        daily_gen = sim.groupby(['fecha','central','tipo'])['mwh_generados'].sum().reset_index()
        fig = px.area(daily_gen, x='fecha', y='mwh_generados', color='central',
                      title="Daily Total Generation by Plant (MWh)",
                      labels={'mwh_generados':'MWh','fecha':'Date'},
                      color_discrete_map={'Los Condores':'#3b82f6','Volcan':'#22c55e','Cerro Pabellon':'#eab308'})
        fig.update_layout(template='plotly_white', height=400)
        st.plotly_chart(fig, use_container_width=True)

        # Generation by hour and type
        hourly_gen = sim.groupby(['hora','tipo'])['mwh_generados'].mean().reset_index()
        fig2 = px.bar(hourly_gen, x='hora', y='mwh_generados', color='tipo', barmode='stack',
                      title="Average Hourly Generation by Type",
                      labels={'mwh_generados':'MWh','hora':'Hour'},
                      color_discrete_map={'hidro':'#3b82f6','eolica':'#22c55e','solar':'#eab308'})
        fig2.update_layout(template='plotly_white', height=350)
        st.plotly_chart(fig2, use_container_width=True)

    with tab3:
        monthly_rev = sim.groupby([sim['fecha'].dt.to_period('M').astype(str), 'central'])['ingreso_usd'].sum().reset_index()
        monthly_rev.columns = ['month','central','revenue_usd']
        fig = px.bar(monthly_rev, x='month', y='revenue_usd', color='central', barmode='group',
                     title="Monthly Revenue by Plant (USD)",
                     labels={'revenue_usd':'Revenue (USD)','month':'Month'},
                     color_discrete_map={'Los Condores':'#3b82f6','Volcan':'#22c55e','Cerro Pabellon':'#eab308'})
        fig.update_layout(template='plotly_white', height=400)
        st.plotly_chart(fig, use_container_width=True)

    with tab4:
        tc = sim.groupby('fecha')['usd_clp'].first().reset_index()
        fig = px.line(tc, x='fecha', y='usd_clp', title="USD/CLP Exchange Rate (2024)",
                      labels={'usd_clp':'CLP per USD','fecha':'Date'})
        fig.update_layout(template='plotly_white', height=350)
        st.plotly_chart(fig, use_container_width=True)


# ════════════════════════════════════════════════════════════════════════════
# FORECAST
# ════════════════════════════════════════════════════════════════════════════
elif page == "🔮 Forecast":
    st.markdown('<p class="main-header">🔮 Price Forecast & Decomposition</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Additive decomposition: Trend + Daily Seasonality + AR(1) Residuals → 7-day forecast</p>', unsafe_allow_html=True)

    sel_barra = st.selectbox("Select barra", ['Quillota', 'Alto Jahuel'])
    fc = forecasts[sel_barra]
    # Ensure components are pd.Series (st.cache_data may deserialize as Index)
    for _k in ('trend', 'seasonal', 'residual'):
        if not isinstance(fc[_k], pd.Series):
            fc[_k] = pd.Series(fc[_k])

    # Metrics
    m = fc['metrics']
    c1,c2,c3 = st.columns(3)
    c1.metric("MAE", f"{m['MAE']:.2f} USD/MWh", help="Mean Absolute Error")
    c2.metric("RMSE", f"{m['RMSE']:.2f} USD/MWh", help="Root Mean Square Error")
    c3.metric("R2", f"{m['R2']:.4f}", help="Variance explained by trend+seasonal")

    st.markdown("---")
    tab1,tab2,tab3 = st.tabs(["Forecast", "Decomposition", "Seasonal Pattern"])

    with tab1:
        ts = prepare_price_series(sim, sel_barra)
        fdf = fc['forecast_df']

        fig = go.Figure()
        # Last 2 weeks of actual
        last14 = ts.iloc[-336:]
        fig.add_trace(go.Scatter(x=last14.index, y=last14.values, name='Actual',
                                  line=dict(color='#1a202c', width=1.5)))
        # Forecast
        fig.add_trace(go.Scatter(x=fdf['timestamp'], y=fdf['forecast'], name='Forecast',
                                  line=dict(color='#1b6ef3', width=2)))
        # CI bands
        fig.add_trace(go.Scatter(x=fdf['timestamp'], y=fdf['upper_95'], line=dict(width=0),
                                  showlegend=False, hoverinfo='skip'))
        fig.add_trace(go.Scatter(x=fdf['timestamp'], y=fdf['lower_95'], fill='tonexty',
                                  fillcolor='rgba(27,110,243,0.1)', line=dict(width=0),
                                  name='95% CI'))
        fig.add_trace(go.Scatter(x=fdf['timestamp'], y=fdf['upper_80'], line=dict(width=0),
                                  showlegend=False, hoverinfo='skip'))
        fig.add_trace(go.Scatter(x=fdf['timestamp'], y=fdf['lower_80'], fill='tonexty',
                                  fillcolor='rgba(27,110,243,0.2)', line=dict(width=0),
                                  name='80% CI'))
        fig.update_layout(title=f"7-Day Price Forecast -- {sel_barra}", template='plotly_white',
                          height=420, yaxis_title='USD/MWh', xaxis_title='Date')
        st.plotly_chart(fig, use_container_width=True)

    with tab2:
        fig = make_subplots(rows=3, cols=1, shared_xaxes=True,
                            subplot_titles=["Trend (24h rolling mean)", "Seasonal (hourly pattern)", "Residuals"])
        # Show last 2 weeks
        last_n = 336
        trend_tail = fc['trend'].iloc[-last_n:]
        seas_tail = fc['seasonal'].iloc[-last_n:]
        res_tail = fc['residual'].iloc[-last_n:]

        fig.add_trace(go.Scatter(x=trend_tail.index, y=trend_tail.values, line=dict(color='#1b6ef3')), row=1,col=1)
        fig.add_trace(go.Scatter(x=seas_tail.index, y=seas_tail.values, line=dict(color='#22c55e')), row=2,col=1)
        fig.add_trace(go.Scatter(x=res_tail.index, y=res_tail.values, line=dict(color='#ef4444')), row=3,col=1)
        fig.update_layout(height=550, template='plotly_white', showlegend=False,
                          title=f"Time Series Decomposition -- {sel_barra} (last 2 weeks)")
        st.plotly_chart(fig, use_container_width=True)

    with tab3:
        sp = fc['seasonal_pattern']
        fig = go.Figure(go.Bar(x=sp.index, y=sp.values,
                               marker_color=['#ef4444' if v > 0 else '#3b82f6' for v in sp.values]))
        fig.update_layout(title=f"Average Seasonal Effect by Hour -- {sel_barra}",
                          xaxis_title='Hour', yaxis_title='USD/MWh deviation from trend',
                          template='plotly_white', height=350)
        st.plotly_chart(fig, use_container_width=True)
        st.caption("Negative = solar depression (hours 10-15), Positive = demand peak (hours 18-22)")


# ════════════════════════════════════════════════════════════════════════════
# ANOMALIES
# ════════════════════════════════════════════════════════════════════════════
elif page == "🔍 Anomalies":
    st.markdown('<p class="main-header">🔍 Anomaly Detection</p>', unsafe_allow_html=True)

    if len(anomalies_df) == 0:
        st.success("No anomalies detected.")
    else:
        c1,c2,c3 = st.columns(3)
        c1.metric("Total Anomalies", len(anomalies_df))
        c2.metric("High Severity", len(anomalies_df[anomalies_df['severity']=='HIGH']))
        c3.metric("Rules Triggered", anomalies_df['rule'].nunique())

        st.markdown("---")
        tab1,tab2 = st.tabs(["Summary", "Details"])

        with tab1:
            c1,c2 = st.columns(2)
            with c1:
                by_rule = anomalies_df['rule'].value_counts().reset_index()
                by_rule.columns = ['rule','count']
                fig = px.bar(by_rule, x='count', y='rule', orientation='h',
                             title="Anomalies by Rule", color='count',
                             color_continuous_scale='OrRd')
                fig.update_layout(template='plotly_white', height=300, showlegend=False)
                st.plotly_chart(fig, use_container_width=True)
            with c2:
                by_sev = anomalies_df['severity'].value_counts().reset_index()
                by_sev.columns = ['severity','count']
                fig = px.pie(by_sev, values='count', names='severity', title="By Severity",
                             color='severity', color_discrete_map={'HIGH':'#ef4444','MEDIUM':'#f59e0b','LOW':'#3b82f6'})
                fig.update_layout(template='plotly_white', height=300)
                st.plotly_chart(fig, use_container_width=True)

        with tab2:
            sev_filter = st.multiselect("Filter by severity", ['HIGH','MEDIUM','LOW'], default=['HIGH','MEDIUM'])
            filtered = anomalies_df[anomalies_df['severity'].isin(sev_filter)]
            st.dataframe(filtered.head(100), use_container_width=True, hide_index=True)


# ════════════════════════════════════════════════════════════════════════════
# SQL CONSOLE
# ════════════════════════════════════════════════════════════════════════════
elif page == "💾 SQL Console":
    st.markdown('<p class="main-header">💾 SQL Console</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Query the mercado table directly</p>', unsafe_allow_html=True)

    st.markdown("""**Table:** `mercado` | **Columns:** timestamp, fecha, hora, barra, central, tipo,
    mwh_generados, precio_spot, moneda, usd_clp, precio_spot_clp, ingreso_usd, ingreso_clp""")

    examples = {
        "Average price by barra": "SELECT barra, ROUND(AVG(precio_spot),2) AS avg_price FROM mercado GROUP BY barra",
        "Generation by type": "SELECT tipo, ROUND(SUM(mwh_generados),0) AS total_mwh FROM mercado GROUP BY tipo ORDER BY total_mwh DESC",
        "Peak vs off-peak": """SELECT barra,
  ROUND(AVG(CASE WHEN hora BETWEEN 18 AND 22 THEN precio_spot END),2) AS peak,
  ROUND(AVG(CASE WHEN hora BETWEEN 0 AND 6 THEN precio_spot END),2) AS offpeak
FROM mercado GROUP BY barra""",
        "Monthly revenue": "SELECT strftime('%Y-%m', fecha) AS month, central, ROUND(SUM(ingreso_usd),0) AS revenue FROM mercado GROUP BY month, central ORDER BY month",
        "Data completeness": """SELECT strftime('%Y-%m', fecha) AS month,
  COUNT(*) AS rows,
  SUM(CASE WHEN precio_spot IS NULL THEN 1 ELSE 0 END) AS null_prices,
  ROUND(100.0*SUM(CASE WHEN precio_spot IS NOT NULL THEN 1 ELSE 0 END)/COUNT(*),1) AS pct_complete
FROM mercado GROUP BY month""",
    }

    selected = st.selectbox("Example queries", ["Custom"] + list(examples.keys()))
    default_q = examples.get(selected, "SELECT * FROM mercado LIMIT 10") if selected != "Custom" else "SELECT * FROM mercado LIMIT 10"
    query = st.text_area("SQL Query", value=default_q, height=120)

    if st.button("Run Query", type="primary"):
        try:
            result = run_sql(conn, query)
            st.dataframe(result, use_container_width=True, hide_index=True)
            st.caption(f"{len(result)} rows returned")
        except Exception as e:
            st.error(f"SQL Error: {e}")


# ════════════════════════════════════════════════════════════════════════════
# AI AGENT
# ════════════════════════════════════════════════════════════════════════════
elif page == "🤖 AI Agent":
    from agent import MarketAgent

    st.markdown('<p class="main-header">🤖 Electricity Market AI Agent</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Powered by Claude via AWS Bedrock -- ask anything about the market data</p>', unsafe_allow_html=True)

    SUGGESTIONS = [
        "What's the average spot price by barra?",
        "How much did Los Condores generate this year?",
        "Compare peak vs off-peak prices",
        "What anomalies were detected?",
        "How reliable is the price forecast?",
        "Give me a market summary",
        "What's the price spread between barras?",
        "Which plant generates the most revenue?",
        "Show me monthly generation trends",
        "What drives the solar dip in prices?",
    ]

    if "market_agent" not in st.session_state:
        with st.spinner("Connecting to Bedrock..."):
            try:
                st.session_state.market_agent = MarketAgent(conn, sim, anomalies_df, forecasts)
                st.session_state.market_ok = True
            except Exception as e:
                st.session_state.market_ok = False
                st.session_state.market_err = str(e)
        st.session_state.market_messages = []

    if not st.session_state.get("market_ok", True):
        st.error(f"Could not connect to Bedrock: {st.session_state.get('market_err','')}")
        st.stop()

    with st.sidebar:
        st.markdown("---")
        if st.button("🔄 New conversation", use_container_width=True, key="agent_reset"):
            st.session_state.market_agent.reset()
            st.session_state.market_messages = []
            st.rerun()
        st.markdown("**Try asking:**")
        for s in SUGGESTIONS:
            if st.button(s, key=f"sug_{s}", use_container_width=True):
                st.session_state["_pending"] = s
        st.markdown("---")
        st.caption("Auth: EC2 IAM role")
        st.caption("Model: Claude Sonnet 4.5")
        st.caption("Tools: 5 available")

    if not st.session_state.market_messages:
        st.markdown("""
        <div class="chat-welcome">
          <h3>⚡ Market Agent</h3>
          <p>I can query the mercado database, analyze price trends,<br>
          explain forecast quality, and report anomalies.<br>
          I use <b>tool calling</b> to pull real data.</p>
        </div>
        """, unsafe_allow_html=True)
    else:
        for msg in st.session_state.market_messages:
            if msg["role"] == "user":
                st.markdown('<div class="chat-label" style="text-align:right">You</div>', unsafe_allow_html=True)
                st.markdown(f'<div class="chat-bubble-user">{msg["content"]}</div>', unsafe_allow_html=True)
            else:
                st.markdown('<div class="chat-label">⚡ Agent</div>', unsafe_allow_html=True)
                for t in msg.get("tool_calls", []):
                    st.markdown(f'<div class="chat-tool">🔧 {t}</div>', unsafe_allow_html=True)
                st.markdown(f'<div class="chat-bubble-agent">{msg["content"]}</div>', unsafe_allow_html=True)

    pending = st.session_state.pop("_pending", None)
    user_input = st.chat_input("Ask about prices, generation, forecasts, anomalies...") or pending

    if user_input:
        st.session_state.market_messages.append({"role": "user", "content": user_input})
        with st.spinner("⚡ Querying tools and reasoning..."):
            try:
                text, tools_used = st.session_state.market_agent.query(user_input)
            except Exception as e:
                text = f"Error: {e}"
                tools_used = []
        st.session_state.market_messages.append({
            "role": "assistant", "content": text,
            "tool_calls": list(dict.fromkeys(tools_used))
        })
        st.rerun()
