"""
agent.py
--------
Electricity Market AI Agent powered by AWS Bedrock.
Tools: SQL queries, data diagnostics, market summary, forecast metrics, price lookup.
"""

import boto3
import json
import pandas as pd
import numpy as np

MODEL_ID = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
REGION = "us-east-2"

SYSTEM_PROMPT = """You are an expert Analytics Engineer AI Agent specialized in the Chilean electricity market (SEN).

You have access to a dataset called 'mercado' with hourly electricity market data for 2024 containing:
- Spot prices (USD/MWh and CLP/MWh) for two barras: Quillota (coastal, near renewables) and Alto Jahuel (Santiago demand center)
- Generation data for three plants: Los Condores (hydro, Quillota), Volcan (wind, Alto Jahuel), Cerro Pabellon (solar, Quillota)
- Exchange rates (USD/CLP)
- Revenue estimates (MWh x price)

DOMAIN KNOWLEDGE:
- Chilean spot prices are set by the Coordinador Electrico Nacional (CEN) based on marginal cost
- Solar depresses midday prices (duck curve effect), demand peaks push evening prices up
- Hydro generation is seasonal: higher in winter (rainfall) in central Chile
- Price spread between barras signals transmission congestion
- The Quillota-Alto Jahuel spread reflects the Santiago import corridor stress

INSTRUCTIONS:
- Use the tools to answer with real data -- never guess numbers
- When writing SQL, use table 'mercado' with columns: timestamp, fecha, hora, barra, central, tipo, mwh_generados, precio_spot, moneda, usd_clp, precio_spot_clp, ingreso_usd, ingreso_clp
- Explain results in the context of the Chilean electricity market
- If asked about forecast quality, use the metrics tool and explain what MAE/RMSE/R2 mean in practical terms
- Always respond in English
- Be concise but insightful -- think like an analyst presenting to a trader or regulator"""


TOOLS = [
    {
        "name": "query_mercado",
        "description": (
            "Execute a SQL query against the 'mercado' table in SQLite. "
            "Use for any question about prices, generation, revenue, trends, or comparisons. "
            "The table has columns: timestamp, fecha, hora, barra, central, tipo, "
            "mwh_generados, precio_spot, moneda, usd_clp, precio_spot_clp, ingreso_usd, ingreso_clp."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "sql": {
                    "type": "string",
                    "description": "SQL query to execute against the mercado table.",
                }
            },
            "required": ["sql"],
        },
    },
    {
        "name": "get_data_diagnostics",
        "description": (
            "Run data quality diagnostics: row count, null rates, value ranges, "
            "anomaly summary. Use when asked about data quality, completeness, or issues."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "get_market_summary",
        "description": (
            "Generate an executive summary of the current market state: "
            "average prices by barra, generation mix, top revenue plants, "
            "and key spreads. Use for overview or report-style questions."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "period": {
                    "type": "string",
                    "description": "Optional: 'last_week', 'last_month', 'ytd', or 'all'. Defaults to 'all'.",
                }
            },
        },
    },
    {
        "name": "get_forecast_metrics",
        "description": (
            "Return the forecast model fit metrics (MAE, RMSE, R2) and explain "
            "how reliable the forecast is. Use when asked about model quality or accuracy."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "barra": {
                    "type": "string",
                    "description": "'Quillota' or 'Alto Jahuel'. Defaults to 'Quillota'.",
                }
            },
        },
    },
    {
        "name": "get_anomaly_report",
        "description": (
            "Return detected anomalies: price spikes, missing data, solar at night, etc. "
            "Use when asked about data issues, outliers, or suspicious patterns."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
        },
    },
]


class DataStore:
    """Holds references to the live data objects for tool execution."""
    def __init__(self, conn, df, anomalies_df, forecast_results):
        self.conn = conn
        self.df = df
        self.anomalies_df = anomalies_df
        self.forecast_results = forecast_results  # dict keyed by barra


def execute_tool(name, params, store):
    """Execute a tool call and return JSON string."""

    if name == "query_mercado":
        sql = params.get("sql", "")
        try:
            result = pd.read_sql(sql, store.conn)
            if len(result) > 50:
                return json.dumps({
                    "result": result.head(50).to_dict(orient="records"),
                    "total_rows": len(result),
                    "note": "Showing first 50 rows. Use LIMIT or aggregation for large results.",
                }, default=str)
            return json.dumps({"result": result.to_dict(orient="records")}, default=str)
        except Exception as e:
            return json.dumps({"error": str(e), "hint": "Check column names and SQL syntax."})

    elif name == "get_data_diagnostics":
        df = store.df
        diag = {
            "total_rows": len(df),
            "date_range": f"{df['timestamp'].min()} to {df['timestamp'].max()}",
            "barras": list(df['barra'].unique()),
            "centrales": list(df['central'].unique()),
            "null_rates": {
                "precio_spot": f"{df['precio_spot'].isnull().mean()*100:.1f}%",
                "mwh_generados": f"{df['mwh_generados'].isnull().mean()*100:.1f}%",
            },
            "price_range_usd": {
                "min": round(float(df['precio_spot'].min()), 2),
                "max": round(float(df['precio_spot'].max()), 2),
                "mean": round(float(df['precio_spot'].mean()), 2),
            },
            "generation_range_mwh": {
                "min": round(float(df['mwh_generados'].min()), 1),
                "max": round(float(df['mwh_generados'].max()), 1),
            },
            "anomalies_detected": len(store.anomalies_df),
        }
        return json.dumps(diag, default=str)

    elif name == "get_market_summary":
        df = store.df
        period = params.get("period", "all")

        if period == "last_week":
            cutoff = df['timestamp'].max() - pd.Timedelta(days=7)
            df = df[df['timestamp'] >= cutoff]
        elif period == "last_month":
            cutoff = df['timestamp'].max() - pd.Timedelta(days=30)
            df = df[df['timestamp'] >= cutoff]

        summary = {
            "period": period,
            "avg_price_by_barra": df.groupby('barra')['precio_spot'].mean().round(2).to_dict(),
            "total_gen_by_type": df.groupby('tipo')['mwh_generados'].sum().round(0).to_dict(),
            "total_gen_by_central": df.groupby('central')['mwh_generados'].sum().round(0).to_dict(),
            "total_revenue_usd_by_central": df.groupby('central')['ingreso_usd'].sum().round(0).to_dict(),
            "peak_vs_offpeak": {
                "avg_price_peak_18_22": round(float(df[df['hora'].between(18,22)]['precio_spot'].mean()), 2),
                "avg_price_offpeak_0_6": round(float(df[df['hora'].between(0,6)]['precio_spot'].mean()), 2),
                "avg_price_solar_10_15": round(float(df[df['hora'].between(10,15)]['precio_spot'].mean()), 2),
            },
            "quillota_altojahuel_spread_avg_usd": round(
                float(df[df['barra']=='Alto Jahuel']['precio_spot'].mean() -
                      df[df['barra']=='Quillota']['precio_spot'].mean()), 2),
        }
        return json.dumps(summary, default=str)

    elif name == "get_forecast_metrics":
        barra = params.get("barra", "Quillota")
        if barra in store.forecast_results:
            m = store.forecast_results[barra]['metrics']
            return json.dumps({
                "barra": barra,
                "metrics": m,
                "interpretation": {
                    "MAE": f"On average the model is off by {m['MAE']:.2f} USD/MWh",
                    "RMSE": f"Root mean squared error of {m['RMSE']:.2f} USD/MWh (penalizes large errors)",
                    "R2": f"The trend+seasonal model explains {m['R2']*100:.1f}% of price variance",
                },
                "model_type": "Additive decomposition: 24h rolling trend + hourly seasonal pattern + AR(1) residuals",
                "forecast_horizon": "168 hours (7 days) with 80% and 95% confidence intervals",
            }, default=str)
        return json.dumps({"error": f"No forecast available for barra '{barra}'"})

    elif name == "get_anomaly_report":
        adf = store.anomalies_df
        if len(adf) == 0:
            return json.dumps({"anomalies": [], "total": 0})
        summary = {
            "total_anomalies": len(adf),
            "by_severity": adf['severity'].value_counts().to_dict(),
            "by_rule": adf['rule'].value_counts().to_dict(),
            "sample": adf.head(20).to_dict(orient="records"),
        }
        return json.dumps(summary, default=str)

    return json.dumps({"error": f"Unknown tool: {name}"})


class MarketAgent:
    """AI Agent for electricity market analysis via Bedrock."""

    def __init__(self, conn, df, anomalies_df, forecast_results):
        self.bedrock = boto3.client("bedrock-runtime", region_name=REGION)
        self.store = DataStore(conn, df, anomalies_df, forecast_results)
        self.history = []

    def query(self, user_message):
        self.history.append({"role": "user", "content": user_message})
        response = self._call(self.history)
        tool_calls_made = []

        while response.get("stop_reason") == "tool_use":
            content = response["content"]
            self.history.append({"role": "assistant", "content": content})

            results = []
            for block in content:
                if block.get("type") == "tool_use":
                    tool_calls_made.append(block["name"])
                    result = execute_tool(block["name"], block["input"], self.store)
                    results.append({
                        "type": "tool_result",
                        "tool_use_id": block["id"],
                        "content": result,
                    })

            self.history.append({"role": "user", "content": results})
            response = self._call(self.history)

        text = ""
        for block in response.get("content", []):
            if block.get("type") == "text":
                text += block["text"]

        self.history.append({"role": "assistant", "content": response.get("content", [])})
        return text, tool_calls_made

    def _call(self, messages):
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 4096,
            "system": SYSTEM_PROMPT,
            "messages": messages,
            "tools": TOOLS,
        }
        resp = self.bedrock.invoke_model(modelId=MODEL_ID, body=json.dumps(body))
        return json.loads(resp["body"].read())

    def reset(self):
        self.history = []
