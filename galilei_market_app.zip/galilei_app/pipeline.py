"""
pipeline.py
-----------
Data cleaning, integration, and synthetic time series generation.
Generates 1 year of hourly data with trend + seasonality + residuals
for realistic simulation since the base dataset has only 6 rows.
"""

import pandas as pd
import numpy as np
import json
import sqlite3
import os

np.random.seed(42)

# ─── Raw data (from the assessment) ──────────────────────────────────────────

def get_raw_data():
    precios_raw = pd.DataFrame({
        'fecha': ['2024-01-01','2024-01-01','2024-01-02','2024-01-02','2024-01-03','2024-01-03'],
        'hora': [8, 20, 8, 20, 8, 20],
        'barra': ['Quillota','Alto Jahuel','Quillota','Alto Jahuel','Quillota','Alto Jahuel'],
        'precio_spot': [45.2, 51.8, None, 49.3, 60.1, None],
        'moneda': ['USD','USD','USD','USD','USD','USD']
    })
    generacion_raw = pd.DataFrame({
        'timestamp': ['2024-01-01 08:00','2024-01-01 20:00','2024-01-02 08:00',
                      '2024-01-02 20:00','2024-01-03 08:00','2024-01-03 20:00'],
        'central': ['Los Condores','Los Condores','Volcan','Volcan','Los Condores','Volcan'],
        'tipo': ['hidro','hidro','eolica','eolica','hidro','eolica'],
        'mwh_generados': [320, 280, 150, 170, 410, 'ERROR'],
        'barra_conexion': ['QUILLOTA-123','QUILLOTA-123','ALTO_JAHUEL-456',
                           'ALTO_JAHUEL-456','QUILLOTA-123','ALTO_JAHUEL-456']
    })
    tipo_cambio_json = '''[
      {"fecha": "2024-01-01", "usd_clp": 895.0},
      {"fecha": "2024-01-02", "usd_clp": 901.5},
      {"fecha": "2024-01-03", "usd_clp": 899.0}
    ]'''
    return precios_raw, generacion_raw, tipo_cambio_json


# ─── Cleaning ─────────────────────────────────────────────────────────────────

def clean_data():
    precios_raw, generacion_raw, tipo_cambio_json = get_raw_data()

    # Clean precios
    precios = precios_raw.copy()
    precios['fecha'] = pd.to_datetime(precios['fecha'])

    # Clean generacion
    generacion = generacion_raw.copy()
    generacion['mwh_generados'] = pd.to_numeric(generacion['mwh_generados'], errors='coerce')
    generacion['timestamp'] = pd.to_datetime(generacion['timestamp'])
    generacion['fecha'] = generacion['timestamp'].dt.normalize()
    generacion['hora'] = generacion['timestamp'].dt.hour
    generacion['barra'] = (
        generacion['barra_conexion']
        .str.split('-').str[0]
        .str.replace('_', ' ')
        .str.title()
    )

    # Parse exchange rate
    tipo_cambio = pd.DataFrame(json.loads(tipo_cambio_json))
    tipo_cambio['fecha'] = pd.to_datetime(tipo_cambio['fecha'])

    # Integrate
    mercado = generacion.merge(
        precios[['fecha', 'hora', 'barra', 'precio_spot', 'moneda']],
        on=['fecha', 'hora', 'barra'], how='left'
    ).merge(tipo_cambio, on='fecha', how='left')

    mercado['precio_spot_clp'] = mercado['precio_spot'] * mercado['usd_clp']
    mercado['ingreso_usd'] = mercado['mwh_generados'] * mercado['precio_spot']
    mercado['ingreso_clp'] = mercado['ingreso_usd'] * mercado['usd_clp']

    return mercado


# ─── Synthetic time series (1 year hourly) ────────────────────────────────────

def generate_synthetic_series():
    """
    Generate 1 year of hourly electricity market data with:
    - Trend: slight upward drift (~0.5% monthly)
    - Seasonality: daily (solar peak at 13h, demand peak at 20h) + annual (winter higher)
    - Residuals: AR(1) process + random shocks
    - Two barras with correlated but different price levels
    - Three generation plants with type-specific patterns
    """
    # Hourly timestamps for 2024
    dates = pd.date_range('2024-01-01', '2024-12-31 23:00', freq='h')
    n = len(dates)

    hours = dates.hour
    day_of_year = dates.dayofyear

    # --- SPOT PRICES ---
    # Base price ~50 USD/MWh
    base_price = 50.0

    # Trend: gradual increase over the year
    trend = np.linspace(0, 8, n)  # +8 USD over the year

    # Annual seasonality: winter months (Jun-Aug in Chile) have higher prices
    # because hydro generation drops and thermal plants set the marginal price
    annual_season = 6 * np.sin(2 * np.pi * (day_of_year - 172) / 365)  # peak at ~Jun 21

    # Daily seasonality: solar depression at noon, demand peak evening
    daily_season = np.zeros(n)
    for i, h in enumerate(hours):
        if 10 <= h <= 15:
            daily_season[i] = -8  # solar pushes prices down midday
        elif 18 <= h <= 22:
            daily_season[i] = 12  # demand peak
        elif 0 <= h <= 5:
            daily_season[i] = -4  # overnight low
        else:
            daily_season[i] = 0

    # AR(1) residuals with occasional shocks
    residuals = np.zeros(n)
    for i in range(1, n):
        residuals[i] = 0.7 * residuals[i-1] + np.random.normal(0, 3)
        # Random price spikes (1% chance per hour)
        if np.random.random() < 0.01:
            residuals[i] += np.random.choice([-15, 20, 30])

    # Quillota: base price, slightly lower (closer to renewables)
    price_quillota = np.maximum(
        base_price + trend + annual_season + daily_season + residuals - 3,
        0  # floor at 0
    )

    # Alto Jahuel: correlated but ~5 USD higher (demand center, Santiago)
    price_alto = np.maximum(
        base_price + trend + annual_season + daily_season * 1.1 + residuals * 0.9 + 5
        + np.random.normal(0, 1.5, n),
        0
    )

    # Exchange rate: random walk around 900 CLP/USD
    usd_clp = np.zeros(n)
    usd_clp[0] = 895.0
    for i in range(1, n):
        # Daily change, same within day
        if hours[i] == 0:
            usd_clp[i] = usd_clp[i-1] + np.random.normal(0, 3)
        else:
            usd_clp[i] = usd_clp[i-1]
    usd_clp = np.clip(usd_clp, 850, 1000)

    # --- GENERATION ---
    # Los Condores (hydro, Quillota): higher in winter (rainfall), 200-450 MWh
    hydro_base = 320
    hydro_annual = 60 * np.sin(2 * np.pi * (day_of_year - 200) / 365)  # peak late winter
    hydro_daily = -30 * np.cos(2 * np.pi * hours / 24)  # slight daily variation
    gen_condores = np.maximum(
        hydro_base + hydro_annual + hydro_daily + np.random.normal(0, 20, n),
        0
    )

    # Volcan (wind, Alto Jahuel): higher at night and in afternoon
    wind_base = 140
    wind_daily = 40 * np.sin(2 * np.pi * (hours - 6) / 24)  # peak at noon
    wind_annual = 20 * np.cos(2 * np.pi * day_of_year / 365)  # higher in winter (wind season)
    gen_volcan = np.maximum(
        wind_base + wind_daily + wind_annual + np.random.normal(0, 25, n),
        0
    )

    # Cerro Pabellon (solar, Quillota): only produces during daylight
    solar_base = np.zeros(n)
    for i, h in enumerate(hours):
        if 7 <= h <= 19:
            solar_base[i] = 180 * np.sin(np.pi * (h - 7) / 12)  # bell curve
        else:
            solar_base[i] = 0
    gen_solar = np.maximum(
        solar_base + np.random.normal(0, 10, n),
        0
    )

    # Build DataFrames
    rows = []
    for i in range(n):
        ts = dates[i]
        # Quillota plants: Los Condores (hydro) + Cerro Pabellon (solar)
        rows.append({
            'timestamp': ts, 'fecha': ts.normalize(), 'hora': int(hours[i]),
            'barra': 'Quillota', 'central': 'Los Condores', 'tipo': 'hidro',
            'mwh_generados': round(gen_condores[i], 1),
            'precio_spot': round(price_quillota[i], 2),
            'moneda': 'USD', 'usd_clp': round(usd_clp[i], 1),
        })
        rows.append({
            'timestamp': ts, 'fecha': ts.normalize(), 'hora': int(hours[i]),
            'barra': 'Quillota', 'central': 'Cerro Pabellon', 'tipo': 'solar',
            'mwh_generados': round(gen_solar[i], 1),
            'precio_spot': round(price_quillota[i], 2),
            'moneda': 'USD', 'usd_clp': round(usd_clp[i], 1),
        })
        # Alto Jahuel plant: Volcan (wind)
        rows.append({
            'timestamp': ts, 'fecha': ts.normalize(), 'hora': int(hours[i]),
            'barra': 'Alto Jahuel', 'central': 'Volcan', 'tipo': 'eolica',
            'mwh_generados': round(gen_volcan[i], 1),
            'precio_spot': round(price_alto[i], 2),
            'moneda': 'USD', 'usd_clp': round(usd_clp[i], 1),
        })

    sim = pd.DataFrame(rows)
    sim['precio_spot_clp'] = sim['precio_spot'] * sim['usd_clp']
    sim['ingreso_usd'] = sim['mwh_generados'] * sim['precio_spot']
    sim['ingreso_clp'] = sim['ingreso_usd'] * sim['usd_clp']

    # Inject ~2% missing prices and ~1% missing generation (realistic)
    null_price_idx = np.random.choice(len(sim), size=int(len(sim) * 0.02), replace=False)
    sim.loc[null_price_idx, 'precio_spot'] = np.nan
    sim.loc[null_price_idx, 'precio_spot_clp'] = np.nan
    sim.loc[null_price_idx, 'ingreso_usd'] = np.nan
    sim.loc[null_price_idx, 'ingreso_clp'] = np.nan

    null_gen_idx = np.random.choice(len(sim), size=int(len(sim) * 0.01), replace=False)
    sim.loc[null_gen_idx, 'mwh_generados'] = np.nan
    sim.loc[null_gen_idx, 'ingreso_usd'] = np.nan
    sim.loc[null_gen_idx, 'ingreso_clp'] = np.nan

    return sim


# ─── Anomaly detection ────────────────────────────────────────────────────────

def detect_anomalies(df):
    """Rule-based anomaly detection for electricity market data."""
    anomalies = []

    # Rule 1: Negative prices
    neg = df[df['precio_spot'] < 0]
    for _, r in neg.iterrows():
        anomalies.append({'timestamp': r['timestamp'], 'barra': r['barra'],
                          'rule': 'negative_price', 'severity': 'HIGH',
                          'detail': f"Price={r['precio_spot']:.2f} USD/MWh"})

    # Rule 2: Extreme prices (>3 std from rolling mean per barra)
    for barra in df['barra'].unique():
        sub = df[df['barra'] == barra].sort_values('timestamp')
        prices = sub['precio_spot'].dropna()
        if len(prices) > 48:
            roll_mean = prices.rolling(48, min_periods=24).mean()
            roll_std = prices.rolling(48, min_periods=24).std()
            z = (prices - roll_mean) / roll_std.clip(lower=1)
            extreme = z.abs() > 3
            for idx in extreme[extreme].index:
                r = sub.loc[idx]
                anomalies.append({'timestamp': r['timestamp'], 'barra': barra,
                                  'rule': 'extreme_price', 'severity': 'MEDIUM',
                                  'detail': f"Price={r['precio_spot']:.2f}, z-score={z.loc[idx]:.1f}"})

    # Rule 3: Missing generation where price exists
    mask = df['mwh_generados'].isna() & df['precio_spot'].notna()
    for _, r in df[mask].iterrows():
        anomalies.append({'timestamp': r['timestamp'], 'barra': r['barra'],
                          'rule': 'missing_generation', 'severity': 'MEDIUM',
                          'detail': f"{r['central']} has price but no generation data"})

    # Rule 4: Solar generation at night
    solar_night = df[(df['tipo'] == 'solar') & (df['mwh_generados'] > 5) &
                     ((df['hora'] < 6) | (df['hora'] > 20))]
    for _, r in solar_night.iterrows():
        anomalies.append({'timestamp': r['timestamp'], 'barra': r['barra'],
                          'rule': 'solar_at_night', 'severity': 'HIGH',
                          'detail': f"Solar gen={r['mwh_generados']:.0f} MWh at hour {r['hora']}"})

    return pd.DataFrame(anomalies) if anomalies else pd.DataFrame(columns=['timestamp','barra','rule','severity','detail'])


# ─── Time series decomposition + forecast ──────────────────────────────────────

def prepare_price_series(df, barra='Quillota'):
    """Aggregate to hourly mean price for a single barra."""
    sub = df[df['barra'] == barra][['timestamp', 'precio_spot']].dropna()
    ts = sub.set_index('timestamp')['precio_spot'].resample('h').mean().dropna()
    return ts


def decompose_and_forecast(ts, forecast_hours=168):
    """
    Manual decomposition + forecast:
    1. Trend via 24h rolling mean
    2. Daily seasonality from residuals
    3. AR(1) on remainder
    4. Reconstruct forecast
    Returns: trend, seasonal, residual components + forecast DataFrame
    """
    from scipy.signal import savgol_filter

    # Trend: 24h rolling mean (smoothed)
    trend = ts.rolling(24, center=True, min_periods=12).mean()
    trend = trend.interpolate().bfill().ffill()

    # Detrended
    detrended = ts - trend

    # Seasonal: average by hour-of-day
    seasonal_pattern = detrended.groupby(detrended.index.hour).mean()
    seasonal = detrended.index.hour.map(seasonal_pattern)
    seasonal.index = detrended.index

    # Residual
    residual = detrended - seasonal

    # Forecast
    last_trend = trend.iloc[-1]
    trend_slope = (trend.iloc[-1] - trend.iloc[-168]) / 168 if len(trend) > 168 else 0

    future_dates = pd.date_range(ts.index[-1] + pd.Timedelta(hours=1),
                                  periods=forecast_hours, freq='h')

    forecast_trend = last_trend + trend_slope * np.arange(1, forecast_hours + 1)
    forecast_seasonal = np.array([seasonal_pattern[h % 24] for h in future_dates.hour])

    # AR(1) residual continuation
    ar_coef = 0.7
    last_res = residual.iloc[-1] if len(residual) > 0 else 0
    forecast_res = np.zeros(forecast_hours)
    for i in range(forecast_hours):
        forecast_res[i] = ar_coef * (forecast_res[i-1] if i > 0 else last_res) + np.random.normal(0, residual.std() * 0.5)

    forecast_vals = forecast_trend + forecast_seasonal + forecast_res

    # Confidence intervals (widening with horizon)
    std_base = residual.std()
    ci_width = std_base * np.sqrt(np.arange(1, forecast_hours + 1) / 24)

    forecast_df = pd.DataFrame({
        'timestamp': future_dates,
        'forecast': forecast_vals,
        'lower_80': forecast_vals - 1.28 * ci_width,
        'upper_80': forecast_vals + 1.28 * ci_width,
        'lower_95': forecast_vals - 1.96 * ci_width,
        'upper_95': forecast_vals + 1.96 * ci_width,
    })

    # Metrics on in-sample fit
    fitted = trend + seasonal + residual * 0  # trend + seasonal only
    mae = np.abs(ts - fitted).mean()
    rmse = np.sqrt(((ts - fitted) ** 2).mean())
    r2 = 1 - ((ts - fitted) ** 2).sum() / ((ts - ts.mean()) ** 2).sum()

    return {
        'trend': trend,
        'seasonal': seasonal,
        'residual': residual,
        'seasonal_pattern': seasonal_pattern,
        'forecast_df': forecast_df,
        'metrics': {'MAE': round(float(mae), 2), 'RMSE': round(float(rmse), 2), 'R2': round(float(r2), 4)},
    }


# ─── SQLite helpers ───────────────────────────────────────────────────────────

def create_db(df):
    conn = sqlite3.connect(':memory:')
    df.to_sql('mercado', conn, index=False, if_exists='replace')
    return conn

def run_sql(conn, query):
    return pd.read_sql(query, conn)
